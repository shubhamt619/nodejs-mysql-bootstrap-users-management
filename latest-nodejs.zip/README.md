# nodejs-mysql-bootstrap-users-management
## How to Run this project ?
After downloading, extract the folder at a good location.
Then go to that directory, open CMD and type 'npm install'
Please note that in order for this project to work,
NodeJs is needed to be installed.

After npm install is complete, 
run 'npm run start'


Now open http://localhost:8080